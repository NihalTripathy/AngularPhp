<?php
	$config['ambulance_type'] = array('Advance Life Support'=>'Advance Life Support', 'Basic Life Support'=>'Basic Life Support', 'Patient Transport'=>'Patient Transport');
	$config['user_status'] = array(1=>'ACTIVE', 0=>'INACTIVE');
	$config['blood_group'] = array('A+'=>'A+', 'A-'=>'A-', 'B+'=>'B+', 'B-'=>'B-', 'O+'=>'O+', 'O-'=>'O-', 'AB+'=>'AB+', 'AB-'=>'AB-');
	$config['no_of_gravida'] = array(0,1,2,3,4,5,6,7,8,9);
	?>