<!DOCTYPE html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Myapp</title>
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Cache-Control" content="no-cache">


<link rel="stylesheet" href="<?php echo base_url(); ?>public/custom/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public/bower_components/font-awesome/css/font-awesome.css" />		
<link href="<?php echo base_url(); ?>public/custom/css/jquery-ui.min.css" rel="stylesheet">

<link href="<?php echo base_url(); ?>public/custom/plugins/bootstrap/css/bootstrapValidator.css" rel="stylesheet" type="text/css" />
<link  href="<?php echo base_url(); ?>public/custom/plugins/sweetalert/css/sweetalert.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/custom/plugins/bootstrap/js/bootstrapValidator.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>public/custom/plugins/sweetalert/js/sweetalert.min.js"></script>
</head>