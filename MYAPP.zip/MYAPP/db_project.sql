-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2022 at 04:53 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicant_reg_master`
--

CREATE TABLE `applicant_reg_master` (
  `id` bigint(20) NOT NULL,
  `reg_user_id` varchar(20) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `mid_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email_id` varchar(500) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `created_by` varchar(20) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applicant_reg_master`
--

INSERT INTO `applicant_reg_master` (`id`, `reg_user_id`, `first_name`, `mid_name`, `last_name`, `email_id`, `mobile`, `password`, `created_by`, `created_on`) VALUES
(10, '', '7008533720', NULL, NULL, NULL, NULL, 'Krishna@1234', '7008533720', '2022-02-24 22:27:06'),
(7, '1111111111', 'SADSA', 'DSADSA', 'DSAD', 'dfdsfds@cfgfd.com', NULL, 'b4dec482af190d5647e7ac637c4a2789fe94c58735f8254819976affc44f118d2d653c14c08eefffa886e177f4fb680455497a9edcc7ae387f8bb44f637dc506', '1111111111', '2022-02-09 22:01:20'),
(13, '1645724165', '7008533721', NULL, NULL, NULL, NULL, 'Krishna@1234', '7008533721', '2022-02-24 23:06:05'),
(14, '1645724219', 'SECRETARIAT', NULL, NULL, NULL, NULL, 'p@ssw0rd', 'SECRETARIAT', '2022-02-24 23:06:59'),
(15, '1645724241', 'SECRETARIAT', NULL, NULL, NULL, NULL, 'p@ssw0rd', 'SECRETARIAT', '2022-02-24 23:07:21'),
(16, '1645724278', 'SECRETARIAT', NULL, NULL, NULL, NULL, 'p@ssw0rd', 'SECRETARIAT', '2022-02-24 23:07:58'),
(17, '1645724313', 'SECRETARIAT', NULL, NULL, NULL, NULL, 'p@ssw0rd', 'SECRETARIAT', '2022-02-24 23:08:33'),
(18, '1645727857', 'SECRETARIAT', NULL, NULL, NULL, NULL, 'p@ssw0rd', 'SECRETARIAT', '2022-02-25 00:07:37'),
(19, '1645727901', 'SECRETARIAT', NULL, NULL, NULL, NULL, 'p@ssw0rd', 'SECRETARIAT', '2022-02-25 00:08:21'),
(20, '1645728576', 'SECRETARIAT', NULL, NULL, NULL, NULL, 'p@ssw0rd', 'SECRETARIAT', '2022-02-25 00:19:36'),
(21, '1645734359', 'SECRETARIAT', NULL, NULL, NULL, NULL, 'p@ssw0rd', 'SECRETARIAT', '2022-02-25 01:55:59'),
(22, '1645734914', 'SECRETARIAT', NULL, NULL, NULL, NULL, 'p@ssw0rd', 'SECRETARIAT', '2022-02-25 02:05:14'),
(23, '1645809654', '7415671000', NULL, NULL, NULL, NULL, 'Mjipl@7410', '7415671000', '2022-02-25 22:50:54'),
(24, '1645842827', '741567102', NULL, NULL, NULL, NULL, 'Mjipl@7410', '741567102', '2022-02-26 08:03:47'),
(25, '1645843414', '7415671000', NULL, NULL, NULL, NULL, 'Mjipl@7410', '7415671000', '2022-02-26 08:13:34'),
(26, '1645843558', '7415671000', NULL, NULL, NULL, NULL, 'Mjipl@7410', '7415671000', '2022-02-26 08:15:58'),
(27, '1645843611', '7415671000', NULL, NULL, NULL, NULL, 'Mjipl@7410', '7415671000', '2022-02-26 08:16:51'),
(28, '1645843773', '7415671000', NULL, NULL, NULL, NULL, 'Mjipl@7410', '7415671000', '2022-02-26 08:19:33'),
(29, '1645843928', '7415671000', NULL, NULL, NULL, NULL, 'Mjipl@7410', '7415671000', '2022-02-26 08:22:08'),
(30, '1645844602', '74156733', NULL, NULL, NULL, NULL, 'Mjipl@7410', '74156733', '2022-02-26 08:33:22'),
(31, '1645844648', '7415671000', NULL, NULL, NULL, NULL, 'Mjipl@7410', '7415671000', '2022-02-26 08:34:08'),
(32, '1645844705', '7415671000', NULL, NULL, NULL, NULL, 'Mjipl@7410', '7415671000', '2022-02-26 08:35:05'),
(33, '1645844763', '741533', NULL, NULL, NULL, NULL, 'Mjipl@7410', '741533', '2022-02-26 08:36:03'),
(34, '1645846701', '7415671000', NULL, NULL, NULL, NULL, 'Mjipl@7410', '7415671000', '2022-02-26 09:08:21'),
(6, '3333333333', 'SDFDS', 'FDSF', 'DSFDSF', 'dsfds@ggg.com', NULL, '9ee8f235502f36090bdc353d19cea8e1e385b21731cda0cbf60b0a9c2094613fa5d31dfc6b954da8e7aaa22d2feccf85a653f36122f3b130a2001528826029dd', '3333333333', '2022-02-09 21:59:57'),
(8, '4444444444', 'ASFDSAF', 'DSFDS', 'FDSF', 'xvcxvxc@hhh.com', NULL, '3848c48fd56a9f5fbb0acfc52a5cb6b6aaddfe40a386736202496874496330b5bd7bc61042ed39e47cb8284cab94c493dbdee7cb76e9494dad05e160eb2663b5', '4444444444', '2022-02-09 22:06:57'),
(9, '8888888888', 'SSSS', 'SSSS', 'SSSS', 'JJJJJ@fff.xcon', NULL, '5f287553cd386c6697fa10637e37baec3488354d7b892e299a7fac2ca413aefeeb46c65269d035d2a3eb969582ceefd6c672b0c810a84d1395c8ad7ac71e2a3e', '8888888888', '2022-02-09 22:52:11');

-- --------------------------------------------------------

--
-- Table structure for table `image_tbl`
--

CREATE TABLE `image_tbl` (
  `id` bigint(50) NOT NULL,
  `image_path` varchar(200) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `image_tbl`
--

INSERT INTO `image_tbl` (`id`, `image_path`, `created_by`, `created_on`) VALUES
(1, 'public/upload/10_39_40pmfe3c6e20ffedd7810fb2d94d7002b5ee.jpg', '4444444444', '2022-02-09 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(11) NOT NULL,
  `title` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_by` varchar(20) NOT NULL,
  `updated_on` datetime NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `description`, `created_by`, `created_on`, `updated_by`, `updated_on`, `status`) VALUES
(1, 'pr 1', 'dsffds dshfds fds fuidsidkjdhsjkfh dk dhk fdsk dkjh fdkh fdksj', '11', '2022-02-22 02:29:20', '11', '2022-02-08 02:29:20', 1),
(2, 'pr 2', 'dsffds dshfds fds fuidsidkjdhsjkfh dk dhk fdsk dkjh fdkh fdksj', '11', '2022-02-22 02:29:20', '11', '2022-02-08 02:29:20', 1),
(3, 'pr 3', 'dsffds dshfds fds fuidsidkjdhsjkfh dk dhk fdsk dkjh fdkh fdksj', '11', '2022-02-22 02:29:20', '11', '2022-02-08 02:29:20', 1),
(4, 'pr 4', 'dsffds dshfds fds fuidsidkjdhsjkfh dk dhk fdsk dkjh fdkh fdksj', '11', '2022-02-22 02:29:20', '11', '2022-02-08 02:29:20', 1),
(5, 'asd', 'er tr tre trt r re', '7415671000', '2022-02-26 07:46:30', '', '0000-00-00 00:00:00', 0),
(6, 'jkh kjh jk kj hhjkh jk', 'h kj hkj hkjh kj hkj hkj hkj hhk kj hjk kj ytddt dfds', '7415671000', '2022-02-26 07:47:37', '', '0000-00-00 00:00:00', 0),
(7, 'asd', 'sadsa', '741533', '2022-02-26 08:36:18', '', '0000-00-00 00:00:00', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applicant_reg_master`
--
ALTER TABLE `applicant_reg_master`
  ADD PRIMARY KEY (`reg_user_id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `image_tbl`
--
ALTER TABLE `image_tbl`
  ADD KEY `id` (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applicant_reg_master`
--
ALTER TABLE `applicant_reg_master`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `image_tbl`
--
ALTER TABLE `image_tbl`
  MODIFY `id` bigint(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
